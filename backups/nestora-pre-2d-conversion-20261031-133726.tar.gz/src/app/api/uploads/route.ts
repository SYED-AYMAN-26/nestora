import { guard, ok, fail } from "@/lib/http";
import { getSessionUser } from "@/lib/auth";
import { saveUpload } from "@/lib/uploads";
import { maxRequestBytes, requestTooLargeMessage } from "@/lib/uploadLimits";

/** Authenticated public-asset upload (resource photos, avatars, condition photos). */
export const POST = guard(async (req: Request) => {
  const user = await getSessionUser();
  if (!user) return fail("Authentication required", 401);
  // Reject an oversized request BEFORE buffering it. On Vercel the platform cap
  // is 4.5 MB, so the app must give its own clear error rather than letting the
  // edge return an opaque 413.
  const declared = Number(req.headers.get("content-length") || 0);
  if (declared > maxRequestBytes) return fail(requestTooLargeMessage(maxRequestBytes), 413);

  const form = await req.formData().catch(() => null);
  if (!form) return fail("Expected multipart/form-data", 400);
  const kind = String(form.get("kind") || "image") as "image" | "document";
  const files = form.getAll("file").filter((f): f is File => f instanceof File);
  if (!files.length) return fail("No file provided", 422);
  if (files.length > 6) return fail("Upload at most 6 files at a time", 422);

  const total = files.reduce((n, f) => n + f.size, 0);
  if (total > maxRequestBytes) return fail(requestTooLargeMessage(maxRequestBytes), 413);

  const urls: string[] = [];
  for (const f of files) {
    const res = await saveUpload(f, kind === "document" ? "document" : "image");
    if (!res.ok) return fail(res.error, 422);
    urls.push(res.url);
  }
  return ok({ urls });
});
